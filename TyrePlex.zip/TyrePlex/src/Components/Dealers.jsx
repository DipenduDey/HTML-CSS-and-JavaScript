import React from 'react';
import { services } from '../assets/utils/utils';

export default function Dealers() {
    return (
        <section className="dealers-container">
            <h2>Tyres sold by this Dealer</h2>
            <div className="dealers-list">
                {services.map((service, index) => (
                    <div key={index} className="service">
                        <img
                            className="service-icon"
                            src="https://img.icons8.com/?size=100&id=vs39peee9J56&format=png&color=000000"
                            alt={service.name}
                        />
                        <span className="service-name">{service.name}</span>
                        <button className="book-now">Buy</button>
                    </div>
                ))}
            </div>
        </section>
    );
}